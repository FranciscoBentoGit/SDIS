package pt.tecnico.staysafe.dgs.client;

import org.junit.jupiter.api.*;

public class DgsIT extends BaseIT {
	
	// static members
	// TODO	
	
	
	// one-time initialization and clean-up
	@BeforeAll
	public static void oneTimeSetUp(){
		
	}

	@AfterAll
	public static void oneTimeTearDown() {
		
	}
	
	// initialization and clean-up for each test
	
	@BeforeEach
	public void setUp() {
		
	}
	
	@AfterEach
	public void tearDown() {
		
	}
		
	// tests 
	
	@Test
	public void test() {
		
		
	}

}
