# REST Tic Tac Toe shared library

This small library contains the definition of messages exchanged between the server and the client of the Tic Tac Toe application.


## Instructions for using Maven

To compile and install:

```
mvn install
```



## To configure the Maven project in Eclipse

'File', 'Import...', 'Maven'-'Existing Maven Projects'

'Select root directory' and 'Browse' to the project base folder.

Check that the desired POM is selected and 'Finish'.


----

[SD Faculty](mailto:leic-sod@disciplinas.tecnico.ulisboa.pt)

